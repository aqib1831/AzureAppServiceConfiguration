import { Component, OnInit } from '@angular/core';

@Component({
    template: '<h1>Home</h1>'
})
export class HomeComponent  {
}